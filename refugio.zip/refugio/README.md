# Refugio

App web de bienestar emocional para estudiantes. Es una demo estática (HTML, CSS y JavaScript puro), sin dependencias ni paso de build.

## Pantallas

- **Inicio**: estado de ánimo del día, pausa de 2 minutos y acceso rápido a Apoyo.
- **Comunidad**: publicaciones anónimas, "Me gusta" y opción para compartir cómo te sientes.
- **Apoyo**: chat privado con el psicólogo (simulado) y otras formas de dar el primer paso.
- **Perfil (Mi espacio)**: Semáforo de Apoyo, diario privado y chat privado.

Tus datos (ánimo, semáforo, diario y publicaciones) se guardan solo en tu navegador con `localStorage`.

## Cómo probarla

Abre `index.html` en el navegador, o levanta un servidor local:

```bash
python -m http.server 8000
```

Luego entra a `http://localhost:8000`.

## Publicarla con GitHub Pages

1. Sube el proyecto a un repositorio de GitHub.
2. Ve a **Settings → Pages**.
3. En **Source** elige `Deploy from a branch`, rama `main` y carpeta `/ (root)`.
4. Guarda y espera un minuto. Tu app quedará en `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Estructura

```
refugio/
├── index.html
├── css/styles.css
├── js/app.js
└── README.md
```

## Nota

El chat es solo una simulación y no está conectado a ningún profesional real. Si estás en peligro, contacta a los servicios de emergencia de tu país o a una persona adulta de confianza.
